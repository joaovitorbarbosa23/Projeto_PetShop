package servicos;

import interfaces.Compravel;

import java.io.Serializable;

import enums.*;

public class Servico implements Compravel, Serializable {

	private static final long serialVersionUID = 1L;
	private String nome, descricao;
	private double preco;
	private Categoria categoria;
	private int id;

	/***
	 * Construtor do servico
	 * 
	 * @param nome      - Nome do servico
	 * @param descricao - Descricao do servico
	 * @param preco     - Preco do servico
	 * @param id        - Identificador do servico
	 * @param categoria - categoria do servico
	 */
	public Servico(String nome, String descricao, double preco, Categoria categoria, int id) throws Exception {

		if (nome == null)
			throw new NullPointerException("O nome nao pode ser null");

		if (descricao == null)
			throw new NullPointerException("A descricao nao pode ser null");

		this.nome = nome;
		this.descricao = descricao;
		this.categoria = categoria;
		this.preco = preco;
		this.id = id;
	}

	/***
	 * Recupera o nome do servico
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do servico
	 * 
	 * @param - Novo nome do servico
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupera a descricao do servico
	 * 
	 * @return : String
	 */
	public String getDescricao() {
		return descricao;
	}

	/***
	 * Altera a descricao do servico
	 * 
	 * @param descricao - Nova descricao do servico
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/***
	 * Recupera o preco do servico
	 * 
	 * @return : double
	 */
	public double getPreco() {
		return preco;
	}

	/***
	 * Altera o preco do servico
	 * 
	 * @param preco - Novo preco do servico
	 */
	public void setPreco(double preco) {
		this.preco = preco;
	}

	/***
	 * Recupera a categoria do servico
	 * 
	 * @return : Enum Categoria
	 */
	public Categoria getCategoria() {
		return this.categoria;
	}

	/***
	 * Altera a categoria do servico
	 * 
	 * @param categoria - Nova categoria
	 */
	@SuppressWarnings("rawtypes")
	public void setCategoria(Enum categoria) {
		Categoria ctg = (Categoria) categoria;
		this.categoria = ctg;
	}

	/***
	 * Recupera o id do servico
	 * 
	 * @return - int
	 */
	public int getCodigo() {
		return id;
	}

	/***
	 * Altera o id do servico
	 * 
	 * @param id - Novo id do servico
	 */
	public void setCodigo(int id) {
		this.id = id;
	}

	/***
	 * Recupera todas as informacoes do servico em uma string
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return this.nome;
				
				/*"\nNome: " + this.getNome() + "\nDescricao: " + this.getDescricao() + "\nPreco: R$" + this.getPreco()
				+ "\n" + "\nCategoria: " + this.categoria.name() + "\n" + "\nID: " + this.id + "\n";*/

	}

	/***
	 * Verifica se dois servicos sao iguais a partir do ID
	 * 
	 * @return true se tiverem o mesmo id, senao false
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Servico))
			return false;

		Servico novo = (Servico) obj;

		if (this.getCodigo() == novo.getCodigo())
			return true;

		return false;

	}

}
