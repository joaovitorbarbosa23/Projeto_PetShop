package clientes;

import java.io.Serializable;
import java.util.List;

import exceptions.PetCadastradoException;
import exceptions.PetInexistenteException;
import pets.*;

public class Cliente implements Serializable {

	private static final long serialVersionUID = 1L;
	private int codigo;
	private String nome;
	private List<Animal> pets;

	/***
	 * Construtor de cliente
	 * 
	 * @param nome   - nome do cliente
	 * @param codigo - codigo do cliente
	 * @param pets   - lista com os pets do cliente
	 */
	public Cliente(String nome, int codigo, List<Animal> pets) {
		this.nome = nome;
		this.codigo = codigo;
		this.pets = pets;
	}

	/***
	 * Adiciona um pet a lista do cliente
	 * 
	 * @param pet - pet a ser adicionado
	 * @return : true se o pet ainda nao estiver a lista, senao lanca excecao
	 */
	public boolean adicionaPet(Animal pet) throws Exception {
		if (this.pets.contains(pet))
			throw new PetCadastradoException("O pet ja esta cadastrado!");

		this.pets.add(pet);
		return true;
	}

	/**
	 * Remove um pet da lista
	 * 
	 * @param pet - Pet a ser removido
	 * @return true se o pet estiver na lista e for removido, senao lanca excecao
	 */
	public boolean removePet(Animal pet) throws Exception {
		if (!this.pets.contains(pet))
			throw new PetInexistenteException("O pet nao esta cadastrado!");

		this.pets.remove(pet);
		return true;

	}

	/**
	 * Recupera o codigo do cliente
	 * 
	 * @return : int
	 */
	public int getCodigo() {
		return codigo;
	}

	/***
	 * Altera o codigo do cliente
	 * 
	 * @param codigo - Novo codigo do cliente
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	/***
	 * Recupera o nome do cliente
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do cliente
	 * 
	 * @param nome - Novo nome do cliente
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupera a lista de pets do cliente
	 * 
	 * @return : List<Animal:
	 */
	public List<Animal> getPets() {
		return pets;
	}

	public Animal getPet(int codigo) {
		for (Animal animal : pets) {
			if (animal.getCodigo() == codigo)
				return animal;
		}

		return null;
	}

	@SuppressWarnings("unused")
	public boolean removePet(int codigo) throws Exception {
		Animal pet = null;
		for (Animal animal : pets) {
			if (animal.getCodigo() == codigo) {
				pet = animal;
				pets.remove(pet);
				return true;
			}
		}

		if (pet == null)
			throw new Exception("O pet nao esta cadatrado!");

		return false;
	}

	/***
	 * Altera a lista de pets do cliente
	 * 
	 * @param pets - Nova lista de pets
	 */
	public void setPets(List<Animal> pets) {
		this.pets = pets;
	}

	/***
	 * Recupera uma string contendo as informacoes do cliente
	 * 
	 */
	@Override
	public String toString() {
		String str = "\nNome: " + this.nome + "\nCodigo: " + this.codigo + "\nLista de pets ";

		for (Animal animal : pets)
			str += animal.toString() + "-------------";

		return str;
	}

}
