package produtos;

import java.io.Serializable;

import enums.Categoria;
import interfaces.Compravel;

public class Produto implements Compravel, Serializable {

	private static final long serialVersionUID = 1L;
	private String nome, descricao;
	private double preco;
	private Categoria categoria;
	private int id;

	/***
	 * Construtor do produto
	 * 
	 * @param nome      - Nome do produto
	 * @param descricao - Descricao do produto
	 * @param preco     - Preco do produto
	 * @param id        - Identificador do produto
	 * @param categoria - categoria do produto
	 */
	public Produto(String nome, String descricao, double preco, Categoria categoria, int id) {
		this.nome = nome;
		this.descricao = descricao;
		this.categoria = categoria;
		this.preco = preco;
		this.id = id;
	}

	/***
	 * Recupera o nome do produto
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do produto
	 * 
	 * @param - Novo nome do produto
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupera a descricao do produto
	 * 
	 * @return : String
	 */
	public String getDescricao() {
		return descricao;
	}

	/***
	 * Altera a descricao do produto
	 * 
	 * @param descricao - Nova descricao do produto
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/***
	 * Recupera o preco do produto
	 * 
	 * @return : double
	 */
	public double getPreco() {
		return preco;
	}

	/***
	 * Altera o preco do produto
	 * 
	 * @param preco - Novo preco do produto
	 */
	public void setPreco(double preco) {
		this.preco = preco;
	}

	/***
	 * Recupera a categoria do produto
	 * 
	 * @return : Enum Categoria
	 */
	public Categoria getCategoria() {
		return this.categoria;
	}

	/***
	 * Altera a categoria do produto
	 * 
	 * @param categoria - Nova categoria
	 */
	@SuppressWarnings("rawtypes")
	public void setCategoria(Enum categoria) {
		Categoria ctg = (Categoria) categoria;
		this.categoria = ctg;
	}

	/***
	 * Recupera o id do produto
	 * 
	 * @return - int
	 */
	public int getCodigo() {
		return id;
	}

	/***
	 * Altera o id do produto
	 * 
	 * @param id - Novo id do produto
	 */
	public void setCodigo(int id) {
		this.id = id;
	}

	/***
	 * Recupera todas as informacoes do produto em uma string
	 * 
	 * @return String
	 */
	@Override
	public String toString() {
		return this.getNome();

		/*
		 * "\nNome: " + this.getNome() + "\nDescricao: " + this.getDescricao() +
		 * "\nPreco: R$" + this.getPreco() + "\n" + "\nCategoria: " +
		 * this.categoria.name() + "\n" + "\nID: " + this.id + "\n";
		 */

	}

	/***
	 * Verifica se dois produtos sao iguais a partir do ID
	 * 
	 * @return true se tiverem o mesmo, senao false
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Produto))
			return false;

		Produto novo = (Produto) obj;

		if (this.getCodigo() == novo.getCodigo())
			return true;

		return false;

	}

}
