package pets;

public class Cachorro extends Animal {

	private static final long serialVersionUID = 1L;
	private String nome, especie, raca;
	private int codigo;

	/***
	 * Construtor de animal
	 * 
	 * @param nome    - nome do animal
	 * @param especie - especie do animal
	 * @param raca    - raca do animal
	 * @param codigo  - codigo do animal
	 */
	public Cachorro(String nome, String especie, String raca, int codigo) {
		this.nome = nome;
		this.especie = especie;
		this.raca = raca;
		this.codigo = codigo;
	}

	/***
	 * Recupera o nome do animal
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do animal
	 * 
	 * @param nome - Novo nome do animal
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupera a especie do animal
	 * 
	 * @return : String
	 */
	public String getEspecie() {
		return especie;
	}

	/***
	 * Altera a especie do animal
	 * 
	 * @param especie - Nova especie do animal
	 */
	public void setEspecie(String especie) {
		this.especie = especie;
	}

	/***
	 * Recupera a raca do animal
	 * 
	 * @return : String
	 */
	public String getRaca() {
		return raca;
	}

	/***
	 * Altera a raca do animal
	 * 
	 * @param raca - Nova raca do animal
	 */
	public void setRaca(String raca) {
		this.raca = raca;
	}

	/***
	 * Recupera o codigo do animal
	 * 
	 * @return : int
	 */
	public int getCodigo() {
		return codigo;
	}

	/**
	 * Altera o codigo do animal
	 * 
	 * @param codigo - Novo codigo do animal
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	/***
	 * Recupera uma string contendo as informacoes do animal
	 * 
	 * @return : String
	 */
	@Override
	public String toString() {
		return "\nNome: " + this.nome + "\nEspecie: " + this.especie + "\nRaca: " + this.raca + "\nCodigo: "
				+ this.codigo + "\n";
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Cachorro))
			return false;

		Cachorro novo = (Cachorro) obj;

		if (this.getCodigo() == novo.getCodigo())
			return true;

		return false;
	}

}
