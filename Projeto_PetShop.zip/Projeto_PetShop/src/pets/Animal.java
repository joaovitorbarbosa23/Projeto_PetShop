package pets;

import java.io.Serializable;

public abstract class Animal implements Serializable {
	private static final long serialVersionUID = 1L;

	public abstract int getCodigo();

	public abstract String getNome();

	public abstract String getRaca();

	public abstract String getEspecie();

	public abstract void setCodigo(int codigo);

	public abstract void setNome(String nome);

	public abstract void setRaca(String raca);

	public abstract void setEspecie(String especie);

}
