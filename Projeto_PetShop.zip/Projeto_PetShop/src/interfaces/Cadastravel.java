package interfaces;

public interface Cadastravel {

	public boolean cadastra(Object obj) throws Exception;

	public boolean remove(Object obj) throws Exception;

}
