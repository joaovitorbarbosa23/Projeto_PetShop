package interfaces;

import enums.*;

/***
 * A interface compravel serve para simplificar algumas manipulacoes de arrays
 * em certas classes do programa
 * 
 */
public interface Compravel {

	/***
	 * Recupera o preco de um item
	 * 
	 * @return o preco do produto
	 */
	public double getPreco();

	public String getNome();
	
	public Categoria getCategoria();

	public String getDescricao();

	public int getCodigo();

	/***
	 * Retorna os atributos do item em forma de String
	 * 
	 * @return Caracteristicas do item
	 */
	public String toString();
}
