package pacotes;

import java.io.Serializable;
import java.util.HashSet;
import java.util.List;
import interfaces.*;
import enums.*;

public class Pacote implements Compravel, Serializable {

	private static final long serialVersionUID = 1L;
	public static final double DESCONTO = 15;
	private String nome, descricao;
	private List<Compravel> itens;
	private double preco;
	private HashSet<Categoria> categorias;
	private int id;

	/***
	 * Construtor de pacote
	 * 
	 * @param nome      - Nome do pacote
	 * @param descricao - Descricao do pacote
	 * @param itens     - ArrayList contendo os itens do pacote
	 */
	public Pacote(String nome, String descricao, List<Compravel> itens, int id) {
		this.nome = nome;
		this.descricao = descricao;
		this.itens = itens;
		this.preco = this.calculaPreco();
		this.id = id;
		this.categorias = new HashSet<Categoria>();
	}

	/***
	 * Adiciona um novo item e recalcula o preco do pacote
	 * 
	 * @param servico - item a ser adicionado
	 * @return : true se o item nao estiver na lista, senao false
	 */
	public boolean adicionaItem(Compravel item) {
		if (!(this.itens.contains(item))) {
			itens.add(item);
			this.preco = calculaPreco();
			return true;
		}

		return true;
	}

	/***
	 * Remove um item e recalcula o preco do pacote
	 * 
	 * @param item - item a ser removido
	 * @return : true se o item estiver na lista, senao false
	 */
	public boolean removeItem(Compravel item) {
		if (this.itens.contains(item)) {
			this.itens.remove(item);
			this.preco = calculaPreco();
			return true;
		}

		return false;

	}

	/***
	 * Calcula o preco do pacote a partir do valor total dos produtos e servicos
	 * menos o valor do desconto
	 * 
	 * @return : double
	 */
	private double calculaPreco() {
		double valor = 0;

		for (Compravel item : itens)
			valor += item.getPreco();

		return valor - (valor * (Pacote.DESCONTO / 100));

	}

	/***
	 * Adiciona as categorias dos produtos e servicos em um array de categorias
	 * 
	 * @return retorna uma lista de categorias
	 */
	@SuppressWarnings("unused")
	private void adicionaCategorias() {
		for (Compravel item : itens) {
			this.categorias.add(item.getCategoria());
		}

	}

	/***
	 * Este metodo nao existe em pacote
	 * 
	 * @return retorna null;
	 */
	public Categoria getCategoria() {
		return null;
	}

	/***
	 * Recupera o nome do pacote
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do pacote
	 * 
	 * @param nome - Novo nome do pacote
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupera a descricao do pacote
	 * 
	 * @return : String
	 */
	public String getDescricao() {
		return descricao;
	}

	/***
	 * Altera a descricao do pacote
	 * 
	 * @param descricao - Nova descricao do pacote
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public int getCodigo() {
		return id;
	}

	public void setCodigo(int id) {
		this.id = id;
	}

	/***
	 * Recupera o preco do pacote
	 *
	 * @return : double
	 */
	public double getPreco() {
		return preco;
	}

	/***
	 * Altera o preco do pacote
	 * 
	 * @param preco - Novo preco do pacote
	 */
	public void setPreco(double preco) {
		this.preco = preco;
	}
	
	public List<Compravel> getItems(){
		return this.itens;
	}

	@Override
	public String toString() {
		/*String str = "\nNome: " + this.getNome() + "\nDescricao: " + this.getDescricao() + "\nPreco: " + this.getPreco()
				+ "\nCodigo: " + this.getCodigo() + "\nItens: ";

		for (Compravel item : itens) {
			str += item.toString();
		}

		str += "\nCategorias: ";
		for (Categoria cat : categorias) {
			str += cat.toString() + " ";
		}*/

		return this.getNome();

	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Pacote))
			return false;

		Pacote novo = (Pacote) obj;

		if (this.getCodigo() == novo.getCodigo())
			return true;

		return false;
	}

}
