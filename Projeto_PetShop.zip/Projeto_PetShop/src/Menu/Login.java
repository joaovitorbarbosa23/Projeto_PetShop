/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Menu;
import FuncoesMenu.Caixa;
import FuncoesMenu.TelaAbertura;
import arquivos.Arquivo;

import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.io.Serializable;

import javax.swing.JOptionPane;
import sistema.*;

/**
 *
 * @author JV
 */
public class Login extends javax.swing.JFrame implements Serializable {

	public static PetShop sistema;

	/**
	 * Creates new form TelaAcesso2
	 */
	public Login() {
		initComponents();
		Dimension Tamtela = Toolkit.getDefaultToolkit().getScreenSize();
		Dimension Tamjan = getSize();
		setLocation(new Point((Tamtela.width - Tamjan.width) / 2, (Tamtela.height - Tamjan.height) / 2));

	}

	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		jPasswordField2 = new javax.swing.JPasswordField();
		jLabel2 = new javax.swing.JLabel();
		jLabel3 = new javax.swing.JLabel();
		jTextField1 = new javax.swing.JTextField();
		jButton1 = new javax.swing.JButton();
		jLabel1 = new javax.swing.JLabel();

		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		setTitle("Pet Shop");

		jPasswordField2.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jPasswordField2ActionPerformed(evt);
			}
		});

		jLabel2.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
		jLabel2.setText("Login");

		jLabel3.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
		jLabel3.setText("Senha");

		jTextField1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jTextField1ActionPerformed(evt);
			}
		});

		jButton1.setFont(new java.awt.Font("Consolas", 1, 18)); // NOI18N
		jButton1.setText("Entrar");
		jButton1.addActionListener(new java.awt.event.ActionListener() {
			public void actionPerformed(java.awt.event.ActionEvent evt) {
				jButton1ActionPerformed(evt);
			}
		});

		jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/View/pet shop trabalho.jpg"))); // NOI18N

		javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
				.addGroup(layout.createSequentialGroup()
						.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
								.addGroup(layout.createSequentialGroup().addGap(50, 50, 50)
										.addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60,
												javax.swing.GroupLayout.PREFERRED_SIZE)
										.addGap(0, 0, 0).addComponent(jTextField1,
												javax.swing.GroupLayout.PREFERRED_SIZE, 300,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(layout.createSequentialGroup().addGap(50, 50, 50).addComponent(jLabel3)
										.addGap(10, 10, 10)
										.addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 300,
												javax.swing.GroupLayout.PREFERRED_SIZE))
								.addGroup(layout.createSequentialGroup().addGap(300, 300, 300).addComponent(jButton1,
										javax.swing.GroupLayout.PREFERRED_SIZE, 110,
										javax.swing.GroupLayout.PREFERRED_SIZE))
								.addComponent(jLabel1))
						.addGap(0, 0, 0)));
		layout.setVerticalGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addGroup(layout
				.createSequentialGroup().addGap(100, 100, 100)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel2)
						.addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
				.addGap(18, 18, 18)
				.addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING).addComponent(jLabel3)
						.addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE,
								javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
				.addGap(158, 158, 158).addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 50,
						javax.swing.GroupLayout.PREFERRED_SIZE))
				.addComponent(jLabel1));

		pack();
	}// </editor-fold>//GEN-END:initComponents

	private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jTextField1ActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_jTextField1ActionPerformed

	@SuppressWarnings("deprecation")
	private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jButton1ActionPerformed

		// Alterar neste if para quando o funcionário for cadastrado ele poder logar com
		// sua conta...

		if (jTextField1.getText().equals("adim") && jPasswordField2.getText().equals("123")) {
			sistema = Arquivo.le("arquivo.txt");
			TelaAbertura telab = new TelaAbertura();
			telab.setVisible(true);
			dispose();
		} else if (jTextField1.getText().equals("funcionario") && jPasswordField2.getText().equals("123")) {
			Arquivo.le("arquivo.txt");
			Caixa caixa = new Caixa();
			caixa.setVisible(true);
			dispose();
		} else {
			JOptionPane.showMessageDialog(null, "Acesso negado");
		}

	}// GEN-LAST:event_jButton1ActionPerformed

	private void jPasswordField2ActionPerformed(java.awt.event.ActionEvent evt) {// GEN-FIRST:event_jPasswordField2ActionPerformed
		// TODO add your handling code here:
	}// GEN-LAST:event_jPasswordField2ActionPerformed

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Jadimava SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */
		try {
			for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
				if ("Nimbus".equals(info.getName())) {
					javax.swing.UIManager.setLookAndFeel(info.getClassName());
					break;
				}
			}
		} catch (ClassNotFoundException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (InstantiationException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (IllegalAccessException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		} catch (javax.swing.UnsupportedLookAndFeelException ex) {
			java.util.logging.Logger.getLogger(Login.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
		}
		// </editor-fold>
		// </editor-fold>

		/* Create and display the form */
		java.awt.EventQueue.invokeLater(new Runnable() {
			public void run() {
				new Login().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private javax.swing.JButton jButton1;
	private javax.swing.JLabel jLabel1;
	private javax.swing.JLabel jLabel2;
	private javax.swing.JLabel jLabel3;
	private javax.swing.JPasswordField jPasswordField2;
	private javax.swing.JTextField jTextField1;
	// End of variables declaration//GEN-END:variables
}
