package pagamentos;

public class Dinheiro extends Pagamento {

	private static final long serialVersionUID = 1L;

	/***
	 * Construtor de dinheiro
	 * 
	 * @param valor - valor do pagamento
	 */
	public Dinheiro(double valor) {
		super(valor);
	}

}
