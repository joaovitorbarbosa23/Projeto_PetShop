package pagamentos;

public class Cheque extends Pagamento {

	private static final long serialVersionUID = 1L;

	/***
	 * Construtor de cartao de cheque
	 * 
	 * @param valor - valor do pagamento
	 */
	public Cheque(double valor) {
		super(valor);
	}

}
