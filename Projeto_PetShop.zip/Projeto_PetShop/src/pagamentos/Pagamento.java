package pagamentos;

import java.io.Serializable;

public class Pagamento implements Serializable {

	private static final long serialVersionUID = 1L;
	private double valor;

	/***
	 * Construtor de pagamento
	 * 
	 * @param valor - valor do pagamento
	 */
	public Pagamento(double valor) {
		this.valor = valor;
	}

	/***
	 * Recupera o valor do pagamento
	 * 
	 * @return : double
	 */
	public double getValor() {
		return this.valor;
	}

	/***
	 * Altera o valor de pagamento
	 * 
	 * @param valor - Novo valor de pagamento
	 */
	public void setValor(double valor) {
		this.valor = valor;
	}

}
