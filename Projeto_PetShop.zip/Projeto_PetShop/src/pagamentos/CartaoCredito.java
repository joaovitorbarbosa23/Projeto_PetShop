package pagamentos;

public class CartaoCredito extends Pagamento {

	private static final long serialVersionUID = 1L;

	/***
	 * Construtor de cartao de credito
	 * 
	 * @param valor - valor do pagamento
	 */
	public CartaoCredito(double valor) {
		super(valor);
	}

}
