package exceptions;

import java.io.Serializable;

public class ClienteCadastradoException extends Exception implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 2L;

	public ClienteCadastradoException(String msg) {
		super(msg);
	}

	public ClienteCadastradoException(String msg, Throwable causa) {
		super(msg, causa);
	}

}
