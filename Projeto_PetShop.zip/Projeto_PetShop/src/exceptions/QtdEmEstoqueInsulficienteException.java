package exceptions;

public class QtdEmEstoqueInsulficienteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public QtdEmEstoqueInsulficienteException(String msg) {
		super(msg);
	}

}
