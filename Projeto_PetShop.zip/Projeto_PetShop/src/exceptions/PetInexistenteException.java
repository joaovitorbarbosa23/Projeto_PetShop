package exceptions;

public class PetInexistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PetInexistenteException(String msg) {
		super(msg);
	}
}
