package exceptions;

public class PagamentoInsulficienteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PagamentoInsulficienteException(String msg) {
		super(msg);
	}
}
