package exceptions;

public class ValorEmCaixaInsulficienteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ValorEmCaixaInsulficienteException(String msg) {
		super(msg);
	}

}
