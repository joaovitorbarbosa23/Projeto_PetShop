package exceptions;

public class PetCadastradoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PetCadastradoException(String msg) {
		super(msg);
	}
}
