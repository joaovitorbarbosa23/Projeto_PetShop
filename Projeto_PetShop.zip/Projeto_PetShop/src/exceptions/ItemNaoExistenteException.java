package exceptions;

public class ItemNaoExistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemNaoExistenteException(String msg) {
		super(msg);
	}

}
