package exceptions;

public class FuncionarioCadastradoException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FuncionarioCadastradoException(String msg) {
		super(msg);
	}

}
