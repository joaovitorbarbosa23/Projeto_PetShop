package exceptions;

public class ItemCadastradoException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ItemCadastradoException(String msg) {
		super(msg);
	}

}
