package exceptions;

import java.io.Serializable;

public class ClienteInexistenteException extends Exception implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ClienteInexistenteException(String msg) {
		super(msg);
	}

	public ClienteInexistenteException(String msg, Throwable causa) {
		super(msg, causa);
	}

}
