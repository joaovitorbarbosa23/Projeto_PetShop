package caixa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exceptions.PagamentoInsulficienteException;
import exceptions.ValorEmCaixaInsulficienteException;
import pagamentos.*;

public class Caixa implements Serializable {

	private static final long serialVersionUID = 1L;
	private double quantiaEmCaixa;
	private List<Conta> contas;

	/***
	 * Construtor do caixa
	 * 
	 * @param valor - valor inicial do caixa
	 */
	public Caixa(double valor) {
		this.quantiaEmCaixa = valor;
		this.contas = new ArrayList<Conta>();
	}

	/***
	 * Gera o balanco da movimentacao do caixa ate o momento
	 * 
	 * @return : double
	 */
	public String geraBalanco() {
		String str = "";
		double valor = 0;

		for (Conta conta : contas) {
			str += "\nCódigo da conta: " + conta.getCodigoConta() + "\nValor: " + conta.getValorTotal() + "\nData: "
					+ conta.getData() + "\n--------------\n";
			valor += conta.getValorTotal();

		}
		valor += this.quantiaEmCaixa;
		str += "Valor total: " + valor;
		return str;

	}

	/***
	 * Finaliza o pedido do cliente. Adiciona o pedido ao array de contas e soma o
	 * valor do pagamento efetuado ao montante ja existente no caixa
	 * 
	 * @param conta     - Conta contendo os dados da compra
	 * @param pagamento - Metodo escolhido pelo cliente para efetuar o pagamento
	 * 
	 * @return - true se for aprovado, senao retorna false
	 */
	public boolean realizaPedido(Conta conta, Pagamento pagamento) throws Exception {
		if (conta.getValorTotal() > pagamento.getValor() && pagamento instanceof Dinheiro)
			throw new PagamentoInsulficienteException("Valor insulficiente para realizar a compra!");

		if (geraTroco(conta.getValorTotal(), pagamento.getValor()) > this.quantiaEmCaixa)
			throw new ValorEmCaixaInsulficienteException("O valor em caixa eh insulficiente!");

		this.contas.add(conta);
		this.quantiaEmCaixa += conta.getValorTotal();
		this.quantiaEmCaixa -= conta.getValorTotal();

		return true;
	}

	/***
	 * Gera o valor do troco para o cliente
	 * 
	 * @param valorTotal - Valor total das compras
	 * @param valorPago  - Valor total pago pelo cliente
	 * @return double
	 */
	public double geraTroco(double valorTotal, double valorPago) {
		double aux = valorPago - valorTotal;
		if (aux <= 0)
			return 0;
		return aux;
	}

	/***
	 * Recupera o valor em caixa
	 * 
	 * @return : double
	 */
	public double getQuantiaEmCaixa() {
		return quantiaEmCaixa;
	}

	/***
	 * Altera a quantia em caixa
	 * 
	 * @param quantiaEmCaixa - novo valor da quantia em caixa
	 */
	public void setQuantiaEmCaixa(double quantiaEmCaixa) {
		this.quantiaEmCaixa = quantiaEmCaixa;
	}

}
