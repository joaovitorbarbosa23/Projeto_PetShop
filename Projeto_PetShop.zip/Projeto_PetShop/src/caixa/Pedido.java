package caixa;

import java.io.Serializable;

import interfaces.Compravel;

public class Pedido implements Serializable {

	private static final long serialVersionUID = 1L;
	private Compravel item;
	private int qtd;

	/***
	 * Construtor de pedido
	 * 
	 * @param item - Item comprado
	 * @param qtd  - quantidade comprada (servicos nao podem ter uma qtd maior que
	 *             1)
	 */
	public Pedido(Compravel item, int qtd) {
		this.item = item;
		this.qtd = qtd;
	}

	/***
	 * Recupera o valor total do pedido
	 * 
	 * @return
	 */
	public double getValorTotal() {
		return this.item.getPreco() * this.qtd;
	}

	/***
	 * Recupera o item pedido
	 * 
	 * @return : Compravel
	 */
	public Compravel getItem() {
		return item;
	}

	/***
	 * Altera o item comprado
	 * 
	 * @param item - novo item comprado
	 */
	public void setItem(Compravel item) {
		this.item = item;
	}

	/***
	 * Recupera a quantidade de itens comprados
	 * 
	 * @return : int
	 */
	public int getQtd() {
		return qtd;
	}

	/***
	 * Altera a quantidade comprada
	 * 
	 * @param qtd - Nova quantidade
	 */
	public void setQtd(int qtd) {
		this.qtd = qtd;
	}

	@Override
	public String toString() {
		return "\n" + this.item.toString() + "\nQuantidade comprada: " + this.getQtd() + "\n";
	}

}
