package caixa;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class Conta implements Serializable {

	private static final long serialVersionUID = 1L;
	private Date data;
	private int codigoFuncionario, codigoConta;
	private List<Pedido> itens;

	/***
	 * Construtor de conta. Data e codigo de conta sao gerados automaticamente
	 * 
	 * @param codigoFuncionario - codigo do funcionario que realizou o atendimento
	 * @param itens             - Itens comprados
	 * @param codigoConta       - Codigo da conta feita
	 */
	public Conta(int codigoFuncionario, List<Pedido> itens, int codigoConta) {

		this.codigoFuncionario = codigoFuncionario;
		this.itens = itens;
		this.codigoConta = codigoConta;
		this.data = new Date();

	}

	/***
	 * Recupera o valor total da compra
	 * 
	 * @return
	 */
	public double getValorTotal() {
		double valor = 0;
		for (Pedido pedido : itens)
			valor += pedido.getValorTotal();

		return valor;
	}

	/***
	 * Recupera a data da compra
	 * 
	 * @return : String
	 */
	public String getData() {
		return data.toString();
	}

	/***
	 * Altera a data de compra
	 * 
	 * @param data - nova data de compra
	 */
	public void setData(Date data) {
		this.data = data;
	}

	/***
	 * Recupera o codigo do funcionario
	 * 
	 * @return : int
	 */
	public int getCodigoFuncionario() {
		return codigoFuncionario;
	}

	/***
	 * Altera o codigo do funcionario
	 * 
	 * @param codigoFuncionario - novo codigo do funcionario
	 */
	public void setCodigoFuncionario(int codigoFuncionario) {
		this.codigoFuncionario = codigoFuncionario;
	}

	/**
	 * Recupera o codigo da conta
	 * 
	 * @return : int
	 */
	public int getCodigoConta() {
		return codigoConta;
	}

	/***
	 * Altera o codigo da conta
	 * 
	 * @param codigoConta - novo codigo da conta
	 */
	public void setCodigoConta(int codigoConta) {
		this.codigoConta = codigoConta;
	}

	/***
	 * Recupera a lista de pedidos
	 * 
	 * @return : List<Pedidos>
	 */
	public List<Pedido> getItens() {
		return itens;
	}

	/***
	 * Altera a lista de pedidos
	 * 
	 * @param itens - Nova lista de pedidos
	 */
	public void setItens(List<Pedido> itens) {
		this.itens = itens;
	}

	/***
	 * Recupera uma string contendo as informacoes da conta
	 * 
	 */
	@Override
	public String toString() {
		String str = "\nCodigo do funcionario: " + this.codigoFuncionario + "\nCodigo da conta: " + this.codigoConta;

		for (Pedido pedido : itens) {
			str += pedido.toString() + "\n ---------- \n";
		}

		str += this.getData();

		return str;

	}

}
