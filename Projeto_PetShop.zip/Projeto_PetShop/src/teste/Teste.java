package teste;

import java.util.*;

import sistema.*;
import clientes.*;
import enums.Categoria;
import interfaces.Compravel;
import produtos.Produto;
import servicos.Servico;

public class Teste {

	public static void main(String[] args) {

		
		int caixa = 100;
		int valorCompra = 10;
		int valorPago = 15;
		int troco = valorPago - valorCompra;
		
		int valorFinal = caixa + valorPago - troco;
		
		System.out.println(valorFinal);

	}

}
