package enums;

import java.io.Serializable;

public enum Categoria implements Serializable {

	VESTIVEL, BRINQUEDO, ACESSORIO, RACAO, MEDICAMENTO, BANHO, TOSA, ESCOVACAO_DENTE, ESCOVACAO_PELO, CONSULTA;

	public static Categoria getCategoria(String nome) {
		if (nome.toUpperCase().equals("VESTIVEL"))
			return Categoria.VESTIVEL;

		else if (nome.toUpperCase().equals("BRINQUEDO"))
			return Categoria.BRINQUEDO;

		else if (nome.toUpperCase().equals("ACESSORIO"))
			return Categoria.ACESSORIO;

		else if (nome.toUpperCase().equals("RACAO"))
			return Categoria.RACAO;

		else if (nome.toUpperCase().equals("MEDICAMENTO"))
			return Categoria.MEDICAMENTO;

		else if (nome.toUpperCase().equals("BANHO"))
			return Categoria.BANHO;

		else if (nome.toUpperCase().equals("TOSA"))
			return Categoria.TOSA;

		else if (nome.toUpperCase().equals("ESCOVACAO_DENTE"))
			return Categoria.ESCOVACAO_DENTE;

		else if (nome.toUpperCase().equals("ESCOVACAO_PELO"))
			return Categoria.ESCOVACAO_PELO;

		else if (nome.toUpperCase().equals("CONSULTA"))
			return Categoria.CONSULTA;
		else
			return null;
	}

}
