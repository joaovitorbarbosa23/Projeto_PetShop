package arquivos;

import java.io.*;
import sistema.*;
import java.io.Serializable;

public class Arquivo implements Serializable {

	private static final long serialVersionUID = 1L;

	public static void salva(String arquivo, PetShop sistema) {

		try {
			FileOutputStream fos = new FileOutputStream(arquivo);
			ObjectOutputStream oos = new ObjectOutputStream(fos);
			oos.writeObject(sistema);
			oos.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}

	public static PetShop le(String arquivo) {
		PetShop sis = new PetShop();

		try {
			FileInputStream fos = new FileInputStream(arquivo);
			ObjectInputStream oos = new ObjectInputStream(fos);
			sis = (PetShop) oos.readObject();
			oos.close();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return sis;

	}
}
