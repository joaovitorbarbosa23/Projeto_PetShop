package funcionarios;

import java.io.Serializable;

public class Funcionario implements Serializable {

	private static final long serialVersionUID = 1L;
	private String nome;
	private int codigo;

	/***
	 * Construtor de funcionario
	 * 
	 * @param nome   - nome do funcionario
	 * @param codigo - codigo do funcionario
	 */
	public Funcionario(String nome, int codigo) {
		this.nome = nome;
		this.codigo = codigo;
	}

	/***
	 * Recupera o nome do funcionario
	 * 
	 * @return : String
	 */
	public String getNome() {
		return nome;
	}

	/***
	 * Altera o nome do funcionario
	 * 
	 * @param nome - Novo nome do funcionario
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/***
	 * Recupeara o codigo do funcionario
	 * 
	 * @return : int
	 */
	public int getCodigo() {
		return codigo;
	}

	/***
	 * Altera o codigo do funcionario
	 * 
	 * @param codigo - Novo codigo
	 */
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	/***
	 * Recupera todas as informacoes do funcionario em uma string
	 * 
	 * @return : String
	 */
	@Override
	public String toString() {
		return "\nNome: " + this.nome + "\nCodigo: " + this.codigo + "\n";
	}

	/***
	 * Verifica se dois funcionarios sao iguais a partir do codigo
	 * 
	 * @return true se tiverem o mesmo codigo, senao false
	 */
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Funcionario))
			return false;

		Funcionario novo = (Funcionario) obj;

		if (this.getCodigo() == novo.getCodigo())
			return true;

		return false;

	}

}
