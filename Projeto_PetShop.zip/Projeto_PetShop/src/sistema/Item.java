package sistema;

import java.io.Serializable;

import produtos.Produto;

public class Item implements Serializable {

	private static final long serialVersionUID = 1L;
	private Produto produto;
	private int qtd;

	public Item(Produto produto, int qtd) {
		this.produto = produto;
		this.qtd = qtd;
	}

	public Produto getProduto() {
		return this.produto;
	}

	public void setProduto(Produto produto) {
		this.produto = produto;
	}

	public int getQtd() {
		return qtd;
	}

	public void setQtd(int qtd) {
		this.qtd = qtd;
	}

	public void aumentaQtd(int valor) {
		this.qtd += valor;
	}

	public void diminuiEstoque(int valor) {
		this.qtd -= valor;
	}

	@Override
	public String toString() {
		return this.getProduto().getNome();

		/* this.produto.toString() + "\nQuantidade: " + this.qtd + "\n"; */
	}

	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof Item))
			return false;

		Item novo = (Item) obj;

		if (this.getProduto().equals(novo.getProduto()))
			return true;

		return false;

	}

}
