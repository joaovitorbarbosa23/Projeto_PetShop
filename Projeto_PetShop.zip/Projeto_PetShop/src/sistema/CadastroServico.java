package sistema;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exceptions.ItemCadastradoException;
import exceptions.ItemNaoExistenteException;
import interfaces.Cadastravel;

import servicos.Servico;

public class CadastroServico implements Cadastravel, Serializable {

	private static final long serialVersionUID = 1L;
	private List<Servico> servicos;

	public CadastroServico() {
		this.servicos = new ArrayList<Servico>();

	}

	public boolean cadastra(Object obj) throws Exception {
		Servico servico = (Servico) obj;
		if (this.servicos.contains(servico))
			throw new ItemCadastradoException("O item ja esta cadastrado!");

		this.servicos.add(servico);

		return true;
	}

	public boolean remove(Object obj) throws Exception {
		Servico servico = (Servico) obj;

		if (!this.servicos.contains(servico))
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		this.servicos.remove(servico);

		return true;
	}

	public Servico getServico(int codigo) {
		for (Servico servico : servicos) {
			if (servico.getCodigo() == codigo)
				return servico;
		}

		return null;
	}

	public List<Servico> getServico() {
		return this.servicos;
	}

}
