package sistema;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import exceptions.ItemCadastradoException;
import exceptions.ItemNaoExistenteException;
import interfaces.Cadastravel;
import pacotes.Pacote;

public class CadastroPacote implements Cadastravel, Serializable {

	private static final long serialVersionUID = 1L;
	private List<Pacote> pacotes;

	public CadastroPacote() {
		this.pacotes = new ArrayList<Pacote>();

	}

	public boolean cadastra(Object obj) throws Exception {
		Pacote pacote = (Pacote) obj;
		if (this.pacotes.contains(pacote))
			throw new ItemCadastradoException("O item ja esta cadastrado!");

		this.pacotes.add(pacote);

		return true;
	}

	public boolean remove(Object obj) throws Exception {
		Pacote pacote = (Pacote) obj;
		if (!this.pacotes.contains(pacote))
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		this.pacotes.remove(pacote);

		return true;
	}

	public Pacote getPacote(int codigo) {
		for (Pacote pacote : pacotes) {
			if (pacote.getCodigo() == codigo)
				return pacote;
		}

		return null;
	}

	public List<Pacote> getPacotes() {
		return this.pacotes;
	}

}
