package sistema;

import caixa.*;
import clientes.*;
import exceptions.FuncionarioNaoExistenteException;
import exceptions.ItemNaoExistenteException;
import funcionarios.*;
import pacotes.*;
import pagamentos.*;
import servicos.*;
import java.io.Serializable;
import java.util.List;

public class PetShop implements Serializable {

	private static final long serialVersionUID = 1L;
	private CadastroCliente clientes;
	private CadastroFuncionario funcionarios;
	private CadastroPacote pacotes;
	private Estoque estoque;
	private CadastroServico servicos;
	private Caixa caixa;

	public PetShop() {
		this.clientes = new CadastroCliente();
		this.funcionarios = new CadastroFuncionario();
		this.pacotes = new CadastroPacote();
		this.estoque = new Estoque();
		this.servicos = new CadastroServico();
		this.caixa = null;
	}

	public boolean iniciaCaixa(double valor) throws Exception {
		if (this.caixa != null)
			throw new Exception("O caixa ja esta aberto!");
		
		this.caixa = new Caixa(valor);
		return true;
	}

	public boolean fechaCaixa() {
		this.caixa = null;
		return true;
	}

	public boolean realizaCompra(Conta conta, Pagamento pagamento) throws Exception {
		return this.caixa.realizaPedido(conta, pagamento);
	}

	public boolean cadastraCliente(Cliente cliente) throws Exception {
		return this.clientes.cadastra(cliente);
	}

	public boolean removeCliente(Cliente cliente) throws Exception {
		return this.clientes.remove(cliente);
	}

	public boolean cadastraFuncionario(Funcionario funcionario) throws Exception {
		return this.funcionarios.cadastra(funcionario);
	}

	public boolean removeFuncionario(Funcionario funcionario) throws Exception {
		return this.funcionarios.remove(funcionario);
	}

	public boolean cadastraPacote(Pacote pacote) throws Exception {
		return this.pacotes.cadastra(pacote);
	}

	public boolean removePacote(Pacote pacote) throws Exception {
		return this.pacotes.remove(pacote);
	}

	public boolean adicionaItem(Item item) throws Exception {
		return this.estoque.cadastra(item);
	}

	public boolean removeItem(Item item) throws Exception {
		return this.estoque.remove(item);
	}

	public boolean adicionaServico(Servico servico) throws Exception {
		return this.servicos.cadastra(servico);
	}

	public boolean removeServico(Servico servico) throws Exception {
		return this.servicos.remove(servico);

	}

	public Cliente getUsuario(int codigo) throws Exception {
		Cliente usr = this.clientes.getUsuario(codigo);

		if (usr == null)
			throw new Exception("O cliente nao esta cadastrado!");

		return usr;
	}

	public Item getProduto(int codigo) throws Exception {
		Item produto = this.estoque.getItem(codigo);

		if (produto == null)
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		return produto;
	}

	public Servico getServico(int codigo) throws Exception {
		Servico servico = this.servicos.getServico(codigo);

		if (servico == null)
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		return servico;
	}

	public Pacote getPacote(int codigo) throws Exception {
		Pacote pacote = this.pacotes.getPacote(codigo);

		if (pacote == null)
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		return pacote;
	}

	public Funcionario getFuncionario(int codigo) throws Exception {
		Funcionario funcionario = this.funcionarios.getFuncionario(codigo);

		if (funcionario == null)
			throw new FuncionarioNaoExistenteException("O funcionario nao esta cadastrado!");

		return funcionario;

	}

	public List<Servico> getServicos() {
		return this.servicos.getServico();
	}

	public List<Item> getProdutos() {
		return this.estoque.getProdutos();
	}

	public List<Pacote> getPacotes() {
		return this.pacotes.getPacotes();
	}

	public String geraBalanco() {
		return this.caixa.geraBalanco();
	}

	public Caixa getCaixa() {
		return this.caixa;
	}
}
