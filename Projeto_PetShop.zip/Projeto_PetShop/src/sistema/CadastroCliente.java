package sistema;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import clientes.Cliente;
import exceptions.ClienteCadastradoException;
import exceptions.ClienteInexistenteException;
import interfaces.Cadastravel;

public class CadastroCliente implements Cadastravel, Serializable {

	private static final long serialVersionUID = 1L;
	private List<Cliente> clientes;

	public CadastroCliente() {
		this.clientes = new ArrayList<Cliente>();

	}

	public boolean cadastra(Object obj) throws Exception {
		Cliente cliente = (Cliente) obj;

		if (this.clientes.contains(cliente))
			throw new ClienteCadastradoException("O cliente ja esta cadastrado!");

		this.clientes.add(cliente);

		return true;
	}

	public boolean remove(Object obj) throws Exception {
		Cliente cliente = (Cliente) obj;

		if (!this.clientes.contains(cliente))
			throw new ClienteInexistenteException("O cliente nao esta cadastrado!");

		this.clientes.remove(cliente);

		return true;
	}

	public Cliente getUsuario(int codigo) {
		for (Cliente cliente : clientes) {
			if (cliente.getCodigo() == codigo)
				return cliente;
		}

		return null;

	}

}
