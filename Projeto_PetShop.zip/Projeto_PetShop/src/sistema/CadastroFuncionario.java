package sistema;

import interfaces.Cadastravel;
import funcionarios.Funcionario;
import java.util.List;

import exceptions.FuncionarioCadastradoException;
import exceptions.FuncionarioNaoExistenteException;

import java.io.Serializable;
import java.util.ArrayList;

public class CadastroFuncionario implements Cadastravel, Serializable {

	private static final long serialVersionUID = 1L;
	private List<Funcionario> funcionarios;

	public CadastroFuncionario() {
		this.funcionarios = new ArrayList<Funcionario>();

	}

	public boolean cadastra(Object obj) throws Exception {
		Funcionario funcionario = (Funcionario) obj;
		if (this.funcionarios.contains(funcionario))
			throw new FuncionarioCadastradoException("O funcionario ja esta cadastrado!");

		this.funcionarios.add(funcionario);

		return true;
	}

	public boolean remove(Object obj) throws Exception {
		Funcionario funcionario = (Funcionario) obj;
		if (!this.funcionarios.contains(funcionario))
			throw new FuncionarioNaoExistenteException("O funcionario nao esta cadastrado!");

		this.funcionarios.remove(funcionario);

		return true;
	}

	public Funcionario getFuncionario(int codigo) {
		for (Funcionario funcionario : funcionarios) {
			if (funcionario.getCodigo() == codigo)
				return funcionario;
		}

		return null;
	}

}
