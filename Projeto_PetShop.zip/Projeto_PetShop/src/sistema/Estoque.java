package sistema;

import java.util.List;

import exceptions.ItemCadastradoException;
import exceptions.ItemNaoExistenteException;
import interfaces.Cadastravel;
import produtos.Produto;

import java.io.Serializable;
import java.util.ArrayList;

public class Estoque implements Cadastravel, Serializable {

	private static final long serialVersionUID = 1L;
	private List<Item> estoque;

	public Estoque() {
		this.estoque = new ArrayList<Item>();
	}

	public boolean cadastra(Object obj) throws Exception {
		Item item = (Item) obj;
		if (this.estoque.contains(item))
			throw new ItemCadastradoException("O item ja existe no estoque!");

		this.estoque.add(item);

		return true;
	}

	public boolean remove(Object obj) throws Exception {
		Item item = (Item) obj;
		if (!this.estoque.contains(item))
			throw new ItemNaoExistenteException("O item nao esta cadastrado no estoque!");

		this.estoque.remove(item);

		return true;
	}

	public boolean dimiuiQtd(Item item, int valor) throws Exception {
		int index = getIndexItem(item);
		if (index < 0)
			throw new ItemNaoExistenteException("O item nao esta cadastrado!");

		this.estoque.get(index).diminuiEstoque(valor);
		return true;
	}

	private int getIndexItem(Item item) {
		for (int i = 0; i < estoque.size(); i++) {
			if (estoque.get(i).getProduto().getCodigo() == item.getProduto().getCodigo())
				return i;
		}

		return -1;
	}

	public Item getItem(int codigo) {
		for (Item item : estoque) {
			if (item.getProduto().getCodigo() == codigo)
				return item;

		}

		return null;
	}

	public List<Item> getProdutos() {
		return this.estoque;
	}

}